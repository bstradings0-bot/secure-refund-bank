export enum Role {
  USER = 'USER',
  ADMIN = 'ADMIN',
}

export enum AccountStatus {
  ACTIVE = 'ACTIVE',
  FROZEN = 'FROZEN',
}

export enum CardType {
  VISA = 'VISA',
  MASTERCARD = 'MASTERCARD',
  PREMIUM = 'PREMIUM',
}

export enum CardStatus {
  ACTIVE = 'ACTIVE',
  FROZEN = 'FROZEN',
  CANCELLED = 'CANCELLED',
}

export enum TransactionType {
  INTERNAL = 'INTERNAL',
  BANK = 'BANK',
  SWIFT = 'SWIFT',
  CRYPTO = 'CRYPTO',
  MOBILE = 'MOBILE',
}

export enum TransactionStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
}

export enum RefundStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
}

export enum OtpType {
  EMAIL = 'EMAIL',
  TWO_FA = 'TWO_FA',
  PASSWORD_RESET = 'PASSWORD_RESET',
}

export enum NotificationType {
  TRANSACTION = 'TRANSACTION',
  CARD = 'CARD',
  SECURITY = 'SECURITY',
  SYSTEM = 'SYSTEM',
}

export interface JwtPayload {
  userId: string;
  email: string;
  role: Role;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  error?: string;
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface LoginRequest {
  email: string;
  password: string;
  otpCode?: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  country?: string;
  address?: string;
}

export interface TransferRequest {
  receiverEmail: string;
  amount: number;
  currency: string;
  type: TransactionType;
  description?: string;
}

export interface CardCreateRequest {
  cardType: CardType;
  colorTheme?: string;
  spendingLimit?: number;
  initialBalance?: number;
}

export interface CardUpdateRequest {
  label?: string;
  colorTheme?: string;
  spendingLimit?: number;
}

export interface CardAnalytics {
  card: VirtualCardData;
  totalSpent: number;
  spendingLimit: number;
  remainingLimit: number;
  usagePercent: number;
}

export interface VirtualCardData {
  id: string;
  accountId: string;
  userId: string;
  cardType: CardType;
  cardNumber: string;
  cvv: string;
  expiryDate: string;
  cardholderName: string;
  cardLabel?: string;
  balance: number;
  status: CardStatus;
  spendingLimit: number;
  colorTheme: string;
  createdAt: string;
  updatedAt: string;
}

export interface DashboardData {
  account: {
    id: string;
    balance: number;
    savingsBalance: number;
    cryptoBalance: number;
    currency: string;
    status: AccountStatus;
  };
  recentTransactions: unknown[];
  cards: unknown[];
  notifications: unknown[];
  totalSent: number;
  totalReceived: number;
}
