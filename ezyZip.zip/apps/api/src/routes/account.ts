import { Router, Response } from 'express';
import { authMiddleware, AuthRequest } from '../middleware/auth';
import { accountService } from '../services/account.service';

const router = Router();
router.use(authMiddleware);

router.get('/', async (req: AuthRequest, res: Response) => {
  try {
    const account = await accountService.getAccount(req.userId!);
    res.json({ success: true, data: account });
  } catch (error: any) {
    res.status(404).json({ success: false, message: error.message });
  }
});

router.get('/dashboard', async (req: AuthRequest, res: Response) => {
  try {
    const dashboard = await accountService.getDashboard(req.userId!);
    res.json({ success: true, data: dashboard });
  } catch (error: any) {
    res.status(404).json({ success: false, message: error.message });
  }
});

export default router;
