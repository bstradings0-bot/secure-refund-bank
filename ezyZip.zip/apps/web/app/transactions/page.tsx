'use client';

import { useQuery } from '@tanstack/react-query';
import api from '@/lib/api';
import { motion } from 'framer-motion';
import { FiArrowUp, FiArrowDown, FiSearch, FiDownload, FiFilter } from 'react-icons/fi';
import { useAuth } from '@/hooks/useAuth';
import { useState } from 'react';

export default function TransactionsPage() {
  const { user } = useAuth();
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['transactions', page],
    queryFn: async () => {
      const { data } = await api.get(`/api/transactions?page=${page}&limit=15`);
      return data;
    },
    enabled: !!user,
  });

  const transactions = data?.transactions || [];
  const totalPages = data?.totalPages || 1;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Transactions</h1>
          <p className="text-gray-400 mt-1">Your transaction history</p>
        </div>
        <div className="flex gap-2">
          <button className="btn-secondary flex items-center gap-2 text-sm py-2 px-4">
            <FiFilter className="w-4 h-4" /> Filter
          </button>
          <button className="btn-secondary flex items-center gap-2 text-sm py-2 px-4">
            <FiDownload className="w-4 h-4" /> Export
          </button>
        </div>
      </div>

      <div className="glass-card">
        <div className="p-4 border-b border-white/5">
          <div className="relative">
            <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
            <input type="text" className="input-field pl-12" placeholder="Search by reference or name..." />
          </div>
        </div>

        {isLoading ? (
          <div className="p-6 space-y-3">
            {[1, 2, 3, 4, 5].map((i) => <div key={i} className="h-16 bg-white/5 rounded-xl animate-pulse" />)}
          </div>
        ) : (
          <>
            <div className="divide-y divide-white/5">
              {transactions.map((tx: any, i: number) => {
                const isOutgoing = tx.senderId === user?.id;
                return (
                  <motion.div key={tx.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.03 }} className="flex items-center justify-between p-4 hover:bg-white/[0.02] transition-all">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isOutgoing ? 'bg-red-500/10' : 'bg-emerald-500/10'}`}>
                        {isOutgoing ? <FiArrowUp className="w-4 h-4 text-red-400" /> : <FiArrowDown className="w-4 h-4 text-emerald-400" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">
                          {isOutgoing ? `To ${tx.receiver.firstName} ${tx.receiver.lastName}` : `From ${tx.sender.firstName} ${tx.sender.lastName}`}
                        </p>
                        <p className="text-xs text-gray-500">{tx.type} | {new Date(tx.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-semibold ${isOutgoing ? 'text-red-400' : 'text-emerald-400'}`}>
                        {isOutgoing ? '-' : '+'}${tx.amount.toFixed(2)}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] text-gray-500 font-mono">{tx.referenceNumber}</span>
                        <span className={`badge text-[10px] ${tx.status === 'COMPLETED' ? 'badge-success' : tx.status === 'PENDING' ? 'badge-pending' : 'badge-danger'}`}>{tx.status}</span>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
              {transactions.length === 0 && <div className="text-center py-12"><p className="text-gray-500">No transactions yet</p></div>}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between p-4 border-t border-white/5">
                <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="btn-secondary text-sm py-2 px-4 disabled:opacity-30">Previous</button>
                <span className="text-sm text-gray-400">Page {page} of {totalPages}</span>
                <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="btn-secondary text-sm py-2 px-4 disabled:opacity-30">Next</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
